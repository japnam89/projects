// Member Bean
package exam;

import java.sql.*;

public class DBUtil
{

 public static void clean(Connection con, PreparedStatement ps)
 {
   try
   { if ( ps != null )  ps.close();
     if ( con != null) con.close();
   }
    catch(Exception ex)
   { System.out.println(ex.getMessage()); }
 }

 public static Connection  getConnection() throws Exception
 {
   Class.forName("oracle.jdbc.driver.OracleDriver");
   // connect using Thin driver
   Connection con =  DriverManager.getConnection("jdbc:oracle:thin:@dilbert.humber.ca:1521:grok",
		"n01004445","oracle");
   return con;
 }

} // end of DBUtil bean








