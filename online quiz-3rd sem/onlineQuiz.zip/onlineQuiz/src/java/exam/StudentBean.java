// Item Bean

package exam;

import  java.sql.*;
import  java.util.*;

import  exam.*;

public class StudentBean
{
	String bcode,rollno,pwd, ccode, sname;

	public String getCcode()
	{  return  ccode; }

    public void setCcode(String ccode) {
        this.ccode = ccode;
    }

    public void setSname(String sname) {
        this.sname = sname;
    }

  

    

    public String getSname()
	{  return  sname; }

	public void setBcode(String bcode)
	{
		  this.bcode = bcode;
    }

    public String getBcode()
    {
		  return bcode;
    }

    public void setRollno(String rollno)
	{
	  this.rollno = rollno;
	}

	public String getRollno()
	{
	  return rollno;
    }


	public void setPwd(String pwd)
	{
	  this.pwd = pwd;
    }

    public String getPwd()
    {
		  return pwd;
    }


    public boolean login(String pwd)
    {
	  Connection con = null;
	  PreparedStatement ps = null;
      try
  	  {
		  con = DBUtil.getConnection();
		  ps = con.prepareStatement("select pwd from Students");
                  
		   ResultSet rs = ps.executeQuery();
                   rs.next();
      String actualpwd = rs.getString(1);
      if ( pwd.equals(actualpwd))
        return true;
      else
        return false;
     }
       // end of try
       catch ( Exception ex)
       {
		     System.out.println( ex.getMessage());
		     return false;
       }
       finally
       {
		     DBUtil.clean(con,ps);
	   }
    } // end of login



    public int add(int bcode,String names[], String pwd[])
    {

     Connection con = null;
     PreparedStatement ps = null;
     try
     {
      con = DBUtil.getConnection();
      con.setAutoCommit(false);
      // get next rollno
      Statement st = con.createStatement();
      ResultSet rs = st.executeQuery("select nvl(max(rollno),0) + 1 from students where bcode = " + bcode);
      rs.next();
      int  rollno = rs.getInt(1);
      st.close();

      ps = con.prepareStatement("insert into students values (?,?,?,?)");
      ps.setInt(1,bcode);
      int cnt = 0 ;
      for ( int i = 0 ; i < names.length ; i ++)
      {
		if ( names[i].length() == 0 ) continue;

        ps.setInt(2,rollno);
        ps.setString(3,names[i]);
        ps.setString(4,pwd[i]);
        ps.executeUpdate();
        rollno ++;
        cnt ++;
      }
      con.commit();
      return cnt;
      }
      catch(Exception ex)
      {
       System.out.println( "Error in Student Add " + ex.getMessage());
       try
       { con.rollback(); } catch( Exception dex)
       { }
       return 0;
      }
      finally
      {
        DBUtil.clean(con,ps);
      }

   } // end of add

} // end of bean








